﻿

namespace WebApiDemo.Appliction.Common.Responses
{
    public abstract class ApiResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; } = string.Empty;
    }

    public class ApiResponse<T> : ApiResponse
    {
        public T? Data { get; set; }

        public static ApiResponse<T> Ok(T data, string message = "") => new SuccessResponse<T>(data, message);
        public static ApiResponse<T> Fail(string message) => new ErrorResponse<T>(message);
    }
    public class SuccessResponse<T> : ApiResponse<T>
    {
        public SuccessResponse(T data, string message = "")
        {
            Success = true;
            Message = message;
            Data = data;
        }
    }

    public class ErrorResponse<T> : ApiResponse<T>
    {
        public ErrorResponse(string message)
        {
            Success = false;
            Message = message;
            Data = default;
        }
    }
}
