﻿using WebApiDemo.Domain.Entities;
using WebApiDemo.Application.Contracts.Presistencee;
using WebApiDemo.Appliction.Common.Responses;
using WebApiDemo.Appliction.Contracts.Presistence;
using WebApiDemo.Appliction.Interfaces;

namespace WebApiDemo.Application.Services
{
    public class CountryService : ICountryService
    {
        private readonly ICountryRepository _repository;
        private readonly ICountryApiClient _apiClient;

        public CountryService(ICountryRepository repository, ICountryApiClient apiClient)
        {
            _repository = repository;
            _apiClient = apiClient;
        }

        public async Task<ApiResponse<IEnumerable<Country>>> GetAllCountriesAsync()
        {
            try
            {
                var countries = (await _repository.GetAllAsync()).ToList();

                if (countries.Any())
                    return ApiResponse<IEnumerable<Country>>.Ok(countries);

                var apiCountries = await _apiClient.GetAllCountriesAsync();
                if (apiCountries == null || !apiCountries.Any())
                    return ApiResponse<IEnumerable<Country>>.Fail("No countries found in external API.");

                foreach (var c in apiCountries)
                    await _repository.SaveAsync(c);

                return ApiResponse<IEnumerable<Country>>.Ok(apiCountries);
            }
            catch (Exception ex)
            {
                return ApiResponse<IEnumerable<Country>>.Fail($"Error retrieving countries: {ex.Message}");
            }
        }
        public async Task<ApiResponse<Country>> GetCountryByIsoCodeAsync(string isocode)
        {
            try
            {
                var country = await _repository.GetByIsoCodeAsync(isocode);
                if (country == null)
                    return ApiResponse<Country>.Fail($"Country with isocode {isocode} not found.");

                return ApiResponse<Country>.Ok(country);
            }
            catch (Exception ex)
            {
                return ApiResponse<Country>.Fail($"Error retrieving country: {ex.Message}");
            }
        }
    }
}
