﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiDemo.Appliction.Common.Responses;
using WebApiDemo.Domain.Entities;

namespace WebApiDemo.Appliction.Interfaces
{
    public interface ICountryService
    {
        Task<ApiResponse<IEnumerable<Country>>> GetAllCountriesAsync();
        Task<ApiResponse<Country>> GetCountryByIsoCodeAsync(string isoCode);

    }
}
