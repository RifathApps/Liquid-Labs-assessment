﻿

namespace WebApiDemo.Application.Contracts.Presistence
{
    public interface IAsyncRepository<T> where T : class
    {
        Task<T> GetByIdAsync(Guid id);
        Task<IReadOnlyList<T>> ListAllAsync();
        Task<T> AddAsync(T Entity);
        Task<T> UpdateAsync(T Entity);
        Task<T> DeleteAsync(T Entity);

    }
}
