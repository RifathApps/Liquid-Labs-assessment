﻿using WebApiDemo.Domain.Entities;

namespace WebApiDemo.Application.Contracts.Presistencee
{
    public interface ICountryApiClient
    {
        Task<Country?> GetCountryByIsoCodeAsync(string isoCode);
        Task<IEnumerable<Country>> GetAllCountriesAsync();
    }
}
