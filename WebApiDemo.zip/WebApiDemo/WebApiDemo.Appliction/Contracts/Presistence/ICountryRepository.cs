﻿using WebApiDemo.Domain.Entities;

namespace WebApiDemo.Appliction.Contracts.Presistence
{
    public interface ICountryRepository
    {
        Task<IEnumerable<Country>> GetAllAsync();
        Task<Country?> GetByIsoCodeAsync(string isoCode);
        Task SaveAsync(Country country);
    }
}
