﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApiDemo.Infrastructure.ThirdParty.Models
{
    public class RestCountry
    {
        public NameInfo Name { get; set; } = null!;
        public string[]? Capital { get; set; }
        public string Cca2 { get; set; } = null!;
    }

    public class NameInfo
    {
        public string Common { get; set; } = null!;
    }
}
