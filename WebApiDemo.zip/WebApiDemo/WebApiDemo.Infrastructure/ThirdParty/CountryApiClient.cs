﻿
using Microsoft.Extensions.Configuration;
using System.Text.Json;

using WebApiDemo.Application.Contracts.Presistencee;
using WebApiDemo.Domain.Entities;
using WebApiDemo.Infrastructure.ThirdParty.Common;
using WebApiDemo.Infrastructure.ThirdParty.Models;

namespace WebApiDemo.Infrastructure.ThirdParty
{
    public class CountryApiClient : ApiClientBase, ICountryApiClient
    {
        private readonly string _baseUrl;
        public CountryApiClient(HttpClient httpClient, IConfiguration configuration): base(httpClient)
        {
            _baseUrl = configuration["RestCountriesApi:BaseUrl"];
        }
        public async Task<IEnumerable<Country>> GetAllCountriesAsync()
        {
            var url = $"{_baseUrl}/all?fields=name,capital,cca2";
            var restCountries = await GetAsync<RestCountry[]>(url);
            if (restCountries == null || restCountries.Length == 0)
                return Enumerable.Empty<Country>();

            return restCountries.Select(rc => new Country
            {
                Name = rc.Name.Common,
                IsoCode = rc.Cca2?.ToUpper(),
                Capital = rc.Capital != null && rc.Capital.Length > 0 ? rc.Capital[0] : null
            });
        }

        public async Task<Country?> GetCountryByIsoCodeAsync(string isoCode)
        {
            if (string.IsNullOrWhiteSpace(isoCode))
                throw new ArgumentException("ISO code must be provided.", nameof(isoCode));

            var url = $"{_baseUrl}/alpha/{isoCode}";

            var countries = await GetAsync<RestCountry[]>(url);

            var restCountry = countries?.Length > 0 ? countries[0] : null;
            if (restCountry == null)
                return null;

            return new Country
            {
                Name = restCountry.Name.Common,
                IsoCode = isoCode.ToUpper(),
                Capital = restCountry.Capital != null && restCountry.Capital.Length > 0 ? restCountry.Capital[0] : null
            };
        }

    }
}