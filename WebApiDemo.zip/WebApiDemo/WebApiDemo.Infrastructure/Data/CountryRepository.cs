﻿
using System.Data.SqlClient;
using WebApiDemo.Appliction.Contracts.Presistence;
using WebApiDemo.Domain.Entities;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace WebApiDemo.Infrastructure.Data
{
    public class CountryRepository : ICountryRepository
    {
        private readonly string _connectionString;

        public CountryRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }
        public async Task<IEnumerable<Country>> GetAllAsync()
        {
            var countries = new List<Country>();

            using var conn = new SqlConnection(_connectionString);
            using var cmd = new SqlCommand("SELECT Id, Name, IsoCode, Capital FROM Countries", conn);

            await conn.OpenAsync();
            using var reader = await cmd.ExecuteReaderAsync();

            while (await reader.ReadAsync())
            {
                countries.Add(new Country
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    Capital = reader.IsDBNull(3) ? null : reader.GetString(3)
                });
            }

            return countries;
        }


        public async Task<Country?> GetByIsoCodeAsync(string isoCode)
        {
            const string sql = "SELECT Id, Name, IsoCode, Capital FROM Countries WHERE IsoCode = @IsoCode";

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand(sql, connection);
            command.Parameters.AddWithValue("@IsoCode", isoCode.ToUpper());

            await connection.OpenAsync();

            using var reader = await command.ExecuteReaderAsync();
            if (await reader.ReadAsync())
            {
                return new Country
                {
                    Id = reader.GetInt32(0),
                    Name = reader.IsDBNull(1) ? null : reader.GetString(1),
                    IsoCode = reader.IsDBNull(2) ? null : reader.GetString(2),
                    Capital = reader.IsDBNull(3) ? null : reader.GetString(3),
                };
            }
            return null;
        }

        public async Task SaveAsync(Country country)
        {
            const string sql = @"
                                    INSERT INTO Countries (Name, IsoCode, Capital)
                                    VALUES (@Name, @IsoCode, @Capital);
                                    SELECT CAST(SCOPE_IDENTITY() as int);
                                ";

            using var connection = new SqlConnection(_connectionString);
            using var command = new SqlCommand(sql, connection);

            command.Parameters.AddWithValue("@Name", country.Name ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@IsoCode", country.IsoCode ?? (object)DBNull.Value);
            command.Parameters.AddWithValue("@Capital", country.Capital ?? (object)DBNull.Value);

            await connection.OpenAsync();
            var id = (int)await command.ExecuteScalarAsync();
            country.Id = id;
        }
    }
}
