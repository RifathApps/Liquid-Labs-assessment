﻿using Microsoft.AspNetCore.Mvc;
using WebApiDemo.Appliction.Interfaces;

namespace WebApiDemo.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CountriesController : ControllerBase
    {
        private readonly ICountryService _countryService;

        public CountriesController(ICountryService countryService)
        {
            _countryService = countryService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var result = await _countryService.GetAllCountriesAsync();
            if (result.Success) 
                return Ok(result);

            return BadRequest(result);
        }

        [HttpGet("iso/{isoCode}")]
        public async Task<IActionResult> GetByIsoCode(string isoCode)
        {
            var result = await _countryService.GetCountryByIsoCodeAsync(isoCode);
            if (result.Success && result.Data != null) 
                return Ok(result.Data);

            return NotFound(result);
        }
    }
}
