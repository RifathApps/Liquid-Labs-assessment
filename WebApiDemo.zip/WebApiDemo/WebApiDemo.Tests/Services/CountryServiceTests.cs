﻿using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebApiDemo.Application.Contracts.Presistencee;
using WebApiDemo.Application.Services;
using WebApiDemo.Appliction.Contracts.Presistence;
using WebApiDemo.Domain.Entities;
using Xunit;

namespace WebApiDemo.Tests.Services
{
    public class CountryServiceTests
    {
        private readonly Mock<ICountryRepository> _repositoryMock;
        private readonly Mock<ICountryApiClient> _apiClientMock;
        private readonly CountryService _service;

        public CountryServiceTests()
        {
            _repositoryMock = new Mock<ICountryRepository>();
            _apiClientMock = new Mock<ICountryApiClient>();
            _service = new CountryService(_repositoryMock.Object, _apiClientMock.Object);
        }

        [Fact]
        public async Task GetCountryByIsoCodeAsync_ReturnsFromRepository_IfExists()
        {
            // Arrange
            var isoCode = "US";
            var countryFromDb = new Country { Id = 1, Name = "United States", IsoCode = isoCode, Capital = "Washington" };

            _repositoryMock.Setup(r => r.GetByIsoCodeAsync(isoCode))
                           .ReturnsAsync(countryFromDb);

            // Act
            var result = await _service.GetCountryByIsoCodeAsync(isoCode);

            // Assert
            Assert.True(result.Success);
            Assert.NotNull(result.Data);
            Assert.Equal(countryFromDb.Name, result.Data.Name);

            // Verify API client is never called when data exists in DB
            _apiClientMock.Verify(api => api.GetCountryByIsoCodeAsync(It.IsAny<string>()), Times.Never);
        }

        [Fact]
        public async Task GetCountryByIsoCodeAsync_FetchesFromApiAndSaves_WhenNotInDb()
        {
            // Arrange
            var isoCode = "FR";
            Country nullCountry = null;
            var countryFromApi = new Country { Name = "France", IsoCode = isoCode, Capital = "Paris" };

            _repositoryMock.Setup(r => r.GetByIsoCodeAsync(isoCode))
                           .ReturnsAsync(nullCountry);

            _apiClientMock.Setup(api => api.GetCountryByIsoCodeAsync(isoCode))
                          .ReturnsAsync(countryFromApi);

            _repositoryMock.Setup(r => r.SaveAsync(countryFromApi))
                           .Returns(Task.CompletedTask);

            // Act
            var result = await _service.GetCountryByIsoCodeAsync(isoCode);

            // Assert
            Assert.True(result.Success);
            Assert.NotNull(result.Data);
            Assert.Equal(countryFromApi.Name, result.Data.Name);

            _repositoryMock.Verify(r => r.SaveAsync(countryFromApi), Times.Once);
            _apiClientMock.Verify(api => api.GetCountryByIsoCodeAsync(isoCode), Times.Once);
        }
    }
}